Eine 404 Seite
==============
:slug: 404
:lang: de
:status: hidden

Eine einfache 404 Seite.
