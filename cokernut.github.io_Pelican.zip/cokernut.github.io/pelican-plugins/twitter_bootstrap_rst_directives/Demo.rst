This will be turned into :abbr:`HTML (HyperText Markup Language)`.

Love this music :glyph:`music` 

.. role:: story_time_glyph(glyph)
    :target: http://www.youtube.com/watch?v=5g8ykQLYnX0
    :class: small text-info  

Love this music :story_time_glyph:`music` 

This is an example of code: :code:`<example>`.

This is an example of kbd: :kbd:`<example>`.


.. label-default::
    
    This is a default label content

.. label-primary::
    
    This is a primary label content

.. label-success::
    
    This is a success label content

.. label-info::
    
    This is a info label content

.. label-warning::
    
    This is a warning label content

.. label-danger::
    
    This is a danger label content


.. panel-default::
    :title: panel default title
    
    This is a default panel content

.. panel-primary::
    :title: panel primary title
    
    This is a primary panel content

.. panel-success::
    :title: panel success title
    
    This is a success panel content

.. panel-info::
    :title: panel info title
    
    This is a info panel content

.. panel-warning::
    :title: panel warning title
    
    This is a warning panel content

.. panel-danger::
    :title: panel danger title
    
    This is a danger panel content


.. alert-success::
    
    This is a success alert content

.. alert-info::
    
    This is a info alert content

.. alert-warning::
    
    This is a warning alert content

.. alert-danger::
    
    This is a danger alert content

        
.. media:: http://stuffkit.com/wp-content/uploads/2012/11/Worlds-Most-Beautiful-Lady-Camilla-Belle-HD-Photos-4.jpg
                :height: 750
                :width: 1000
                :scale: 20
                :target: http://www.google.com
                :alt: Camilla Belle
                :position: left

                .. class:: h3

                    left position

                This image is not mine. Credit goes to http://stuffkit.com
                


.. media:: http://stuffkit.com/wp-content/uploads/2012/11/Worlds-Most-Beautiful-Lady-Camilla-Belle-HD-Photos-4.jpg
                :height: 750
                :width: 1000
                :scale: 20
                :target: http://www.google.com
                :alt: Camilla Belle
                :position: right

                .. class:: h3

                    right position


                This image is not mine. Credit goes to http://stuffkit.com