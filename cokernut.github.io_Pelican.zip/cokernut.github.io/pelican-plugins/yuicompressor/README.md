# YUI Compressor Plugin

A pelican plugin which minify through yui compressor CSS/JS file on building step.

# Installation

In order to work, JRE should be already installed.
Please add `pip install yuicompressor`

More info : (https://github.com/yui/yuicompressor)

# Instructions

Add `yuicompressor` to `pelicanconf.py` after install :
`PLUGINS = ['yuicompressor']`

# Licence

GNU AFFERO GENERAL PUBLIC LICENSE Version 3
